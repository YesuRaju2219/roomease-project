const a = require('./helpers.js')
console.log(a.createHash('a'));