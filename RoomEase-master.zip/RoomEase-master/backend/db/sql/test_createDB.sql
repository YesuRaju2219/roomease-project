DROP DATABASE IF EXISTS roomease_test;
CREATE DATABASE roomease_test;